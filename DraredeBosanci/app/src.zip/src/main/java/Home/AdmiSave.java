package Home;

public class AdmiSave {
    String mail;

    public AdmiSave(String mail) {
        this.mail = mail;

    }

    public String getEmail() {
        return mail;
    }





}
